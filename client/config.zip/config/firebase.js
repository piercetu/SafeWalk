const config = {
    apiKey: "AIzaSyDySsEHF8PZP5aDMYeWAr5dQ3E9VvutACE",
    authDomain: "safewalk-26e6c.firebaseapp.com",
    databaseURL: "https://safewalk-26e6c.firebaseio.com",
    projectId: "safewalk-26e6c",
    storageBucket: "",
    messagingSenderId: "201942705376"
  };
  firebase.initializeApp(config);
  db = firebase.database();